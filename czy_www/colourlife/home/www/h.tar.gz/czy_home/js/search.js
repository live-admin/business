$(function(){
    console.log($.cookie('czy_username'));
    if($.cookie('czy_username')!=""&&$.cookie('czy_username')!==null){
        $(".about-info>ul>li:nth-child(1)").css("display",'block');
         $(".about-info>ul>li:nth-child(2)").css("display",'block');
        $(".twoczy_username").html($.cookie('czy_username'));
    }
    //退出
    $(".sign_out").click(function(){
        $(".about-info>ul>li:nth-child(1)").css("display",'none');
         $(".about-info>ul>li:nth-child(2)").css("display",'none');
        var cookietime = new Date();
        var timestamp=new Date().getTime();
        cookietime.setTime(timestamp + (60 * 60 * 1000));//coockie保存一小时
        $.cookie("czy_username",'',{expires:cookietime,path:'/'});
        //$.cookie("czy_username",null);
        console.log($.cookie('czy_username'));
        window.location.href="../index.html"
    });
   $(".search").click(function(){
       $(".nav ul:nth-child(1)").css("display",'none');
       $("#sou_banner").css("display",'block');
   });
    $("#sou_banner>li:nth-child(3)").click(function(){
        $(".nav ul:nth-child(1)").css("display",'block');
        $("#sou_banner").css("display",'none');
    });
    ////彩之云app提示
    //$(".close_czyAPP").click(function(){
    //    $(".czy_app").css("display","none")
    //});
    //$(".app_czydown").click(function(){
    //    $(".czy_app").css("display","block")
    //});
    //联系客服
    $(".close_Customerservice").click(function(){
        $(".czy_Customerservice").css("display","none")
    });
    $(".app_Customer").click(function(){
        $(".czy_Customerservice").css("display","block")
    });
//    了解更多
//    $(".Learn_more").click(function(){
//        $(".czy_app").css("display","block")
//    });
//    $(".View_details").click(function(){
//        $(".czy_app").css("display","block")
//    });
    //关闭彩之云弹窗
    //$(".come_onczy button").click(function(){
    //    $(".czy_app").css("display","none")
    //});
    //$(".sample li").click(function(){
    //    $(".czy_app").css("display","block");
    //});
    //$(".left_arrow").click(function(){
    //    $(".czy_app").css("display","block");
    //});
    //$(".right_arrow").click(function(){
    //    $(".czy_app").css("display","block");
    //})
});